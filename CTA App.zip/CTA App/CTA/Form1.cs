﻿
using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CTA
{

  public partial class Form1 : Form
  {
    private string BuildConnectionString()
    {
      string version = "MSSQLLocalDB";
      string filename = this.txtDatabaseFilename.Text;

      string connectionInfo = String.Format(@"Data Source=(LocalDB)\{0};AttachDbFilename={1};Integrated Security=True;", version, filename);

      return connectionInfo;
    }

    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      //
      // setup GUI:
      //
      this.lstStations.Items.Add("");
      this.lstStations.Items.Add("[ Use File>>Load to display L stations... ]");
      this.lstStations.Items.Add("");

      this.lstStations.ClearSelected();

      toolStripStatusLabel1.Text = string.Format("Number of stations:  0");

      // 
      // open-close connect to get SQL Server started:
      //
      SqlConnection db = null;

      try
      {
		  BusinessTier.Business bizTier;
		  bizTier = new BusinessTier.Business(this.txtDatabaseFilename.Text);
		  bizTier.TestConnection();
      }
      finally
      {
        // close connection:
      }
    }


    //
    // File>>Exit:
    //
    private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
    {
      this.Close();
    }


    //
    // File>>Load stations:
    //
    private void toolStripMenuItem2_Click(object sender, EventArgs e)
    {

      // clear the UI of any current results:
      ClearStationUI(true);

      // load the stations from the database
      try
      {
        BusinessTier.Business bizTier;
        bizTier = new BusinessTier.Business(this.txtDatabaseFilename.Text);
        var stations = bizTier.GetStations();
        foreach(BusinessTier.CTAStation station in stations)
                {
                    this.lstStations.Items.Add(station.Name);
                }
        toolStripStatusLabel1.Text = string.Format("Number of stations:  {0:#,##0}", stations.Count);
      }
      catch (Exception ex)
      {
        string msg = string.Format("Error Loading Stations: '{0}'.", ex.Message);
        MessageBox.Show(msg);
      }
    }


    //
    // User has clicked on a station for more info:
    //
    private void lstStations_SelectedIndexChanged(object sender, EventArgs e)
    {
      // returns if this event fires, but nothing is selected
      if (this.lstStations.SelectedIndex < 0)   
        return; 
     
      // clear GUI in case this fails:
      ClearStationUI();

      // adjust station names for SQL formatting
      string stationName = this.lstStations.Text;
      stationName = stationName.Replace("'", "''");

	  SqlConnection db = null;

	  // display info about selected station:
      try
      {
        db = new SqlConnection(BuildConnectionString());
        db.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = db;

        // we need total overall ridership for %:
        string sql = string.Format(@"
		SELECT Sum(Convert(bigint,DailyTotal)) As TotalOverall
		FROM Riderships;
		");


        cmd.CommandText = sql;
        object result = cmd.ExecuteScalar();
        long totalOverall = Convert.ToInt64(result);


        // we need total and avg ridership for this station:
        sql = string.Format(@"
		SELECT Sum(DailyTotal) As TotalRiders, Avg(DailyTotal) As AvgRiders
		FROM Riderships
		INNER JOIN Stations ON Riderships.StationID = Stations.StationID
		WHERE Name = '{0}';
		", stationName);


        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        cmd.CommandText = sql;
        adapter.Fill(ds);

        System.Diagnostics.Debug.Assert(ds.Tables["TABLE"].Rows.Count == 1);
        DataRow R = ds.Tables["TABLE"].Rows[0];

        int stationTotal = Convert.ToInt32(R["TotalRiders"]);
        double stationAvg = Convert.ToDouble(R["AvgRiders"]);
        double percentage = ((double)stationTotal) / totalOverall * 100.0;

        this.txtTotalRidership.Text = stationTotal.ToString("#,##0");
        this.txtAvgDailyRidership.Text = string.Format("{0:#,##0}/day", stationAvg);
        this.txtPercentRidership.Text = string.Format("{0:0.00}%", percentage);


        // now ridership values for weekday, saturday, and sunday/holiday:
        sql = string.Format(@"
		DECLARE @id as int;
		DECLARE @weekday as int;
		DECLARE @saturday as int;
		DECLARE @sunday as int;
		SET @id = (
		 SELECT StationID FROM Stations
		 WHERE Name = '{0}');
		SET @weekday = (
		 SELECT Sum(DailyTotal) FROM Riderships
		 INNER JOIN Stations ON Riderships.StationID = Stations.StationID
		 WHERE Name = '{0}' AND
			   TypeOfDay = 'W');
		SET @saturday = (
		 SELECT Sum(DailyTotal) FROM Riderships
		 INNER JOIN Stations ON Riderships.StationID = Stations.StationID
		 WHERE Name = '{0}' AND
			   TypeOfDay = 'A');
		SET @sunday = (
		 SELECT Sum(DailyTotal) FROM Riderships
		 INNER JOIN Stations ON Riderships.StationID = Stations.StationID
		 WHERE Name = '{0}' AND
			   TypeOfDay = 'U');
		SELECT @id AS StationID,
			   @weekday AS Weekday,
			   @saturday AS Saturday,
			   @sunday AS SundayHoliday;
		", stationName);

        ds.Clear();

        cmd.CommandText = sql;
        adapter.Fill(ds);

        System.Diagnostics.Debug.Assert(ds.Tables["TABLE"].Rows.Count == 1);
        R = ds.Tables["TABLE"].Rows[0];

        int stationID = Convert.ToInt32(R["StationID"]);
        this.txtStationID.Text = stationID.ToString();

        int total = Convert.ToInt32(R["Weekday"]);
        this.txtWeekdayRidership.Text = total.ToString("#,##0");

        total = Convert.ToInt32(R["Saturday"]);
        this.txtSaturdayRidership.Text = total.ToString("#,##0");

        total = Convert.ToInt32(R["SundayHoliday"]);
        this.txtSundayHolidayRidership.Text = total.ToString("#,##0");


      // display the stops of the selected station
      BusinessTier.Business bizTier;
      bizTier = new BusinessTier.Business(this.txtDatabaseFilename.Text);
      var stops = bizTier.GetStops(Convert.ToInt32(this.txtStationID.Text));
      foreach(var stop in stops)
                {
                    this.lstStops.Items.Add(stop.Name);
                }
      }
      catch (Exception ex)
      {
        string msg = string.Format("Error displaying station stops: '{0}'.", ex.Message);
        MessageBox.Show(msg);
      }
      finally
      {
        if (db != null && db.State == ConnectionState.Open)
          db.Close();
      }
    }


    //
	// clear the station and stops ui
	//
    private void ClearStationUI(bool clearStatations = false)
    {
      ClearStopUI();

      this.txtTotalRidership.Clear();
      this.txtTotalRidership.Refresh();

      this.txtAvgDailyRidership.Clear();
      this.txtAvgDailyRidership.Refresh();

      this.txtPercentRidership.Clear();
      this.txtPercentRidership.Refresh();

      this.txtStationID.Clear();
      this.txtStationID.Refresh();

      this.txtWeekdayRidership.Clear();
      this.txtWeekdayRidership.Refresh();
      this.txtSaturdayRidership.Clear();
      this.txtSaturdayRidership.Refresh();
      this.txtSundayHolidayRidership.Clear();
      this.txtSundayHolidayRidership.Refresh();

      this.lstStops.Items.Clear();
      this.lstStops.Refresh();

      if (clearStatations)
      {
        this.lstStations.Items.Clear();
        this.lstStations.Refresh();
      }
    }


    //
    // user has clicked on a stop for more info:
    //
    private void lstStops_SelectedIndexChanged(object sender, EventArgs e)
    {
      // returns if this event fires, but nothing is selected
      if (this.lstStops.SelectedIndex < 0)
        return; 

      // clear GUI in case this fails:
      ClearStopUI();

      // display info about this stop:
      string stopName = this.lstStops.Text;
      stopName = stopName.Replace("'", "''");

      SqlConnection db = null;

      try
      {
        db = new SqlConnection(BuildConnectionString());
        db.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.Connection = db;

        //display info about the stop:
        string sql = string.Format(@"
		SELECT StopID, Direction, ADA, Latitude, Longitude
		FROM Stops
		WHERE Name = '{0}' AND StationID = {1};", 
		stopName, this.txtStationID.Text);

        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();

        cmd.CommandText = sql;
        adapter.Fill(ds);

        System.Diagnostics.Debug.Assert(ds.Tables["TABLE"].Rows.Count == 1);
        DataRow R = ds.Tables["TABLE"].Rows[0];

        // handicap accessible?
        bool accessible = Convert.ToBoolean(R["ADA"]);

        if (accessible)
          this.txtAccessible.Text = "Yes";
        else
          this.txtAccessible.Text = "No";

        // direction of travel:
        this.txtDirection.Text = R["Direction"].ToString();

        // lat/long position:
        this.txtLocation.Text = string.Format("({0:00.0000}, {1:00.0000})", 
          Convert.ToDouble(R["Latitude"]), 
          Convert.ToDouble(R["Longitude"]));


        // now we need to know what lines are associated with this stop:
        int stopID = Convert.ToInt32(R["StopID"]);

        sql = string.Format(@"
		SELECT Color
		FROM Lines
		INNER JOIN StopDetails ON Lines.LineID = StopDetails.LineID
		INNER JOIN Stops ON StopDetails.StopID = Stops.StopID
		WHERE Stops.StopID = {0}
		ORDER BY Color ASC;
		", stopID);

        ds.Clear();

        cmd.CommandText = sql;
        adapter.Fill(ds);

        // display colors of the L lines:
        foreach (DataRow row in ds.Tables["TABLE"].Rows)
        {
          this.lstLines.Items.Add(row["Color"].ToString());
        }
      }
      catch (Exception ex)
      {
        string msg = string.Format("Error displaying stop info: '{0}'.", ex.Message);
        MessageBox.Show(msg);
      }
      finally
      {
        if (db != null && db.State == ConnectionState.Open)
          db.Close();
      }
    }

	//
    // clear stop ui only
    //
    private void ClearStopUI()
    {
      this.txtAccessible.Clear();
      this.txtAccessible.Refresh();

      this.txtDirection.Clear();
      this.txtDirection.Refresh();

      this.txtLocation.Clear();
      this.txtLocation.Refresh();

      this.lstLines.Items.Clear();
      this.lstLines.Refresh();
    }


    //
    // Top-10 stations in terms of ridership:
    //
    private void top10StationsByRidershipToolStripMenuItem_Click(object sender, EventArgs e)
    {
      // clear the UI of any current results:
      ClearStationUI(true /*clear stations*/);

  
	  // now load top-10 stations:
	  try
      {
      BusinessTier.Business bizTier;
      bizTier = new BusinessTier.Business(this.txtDatabaseFilename.Text);
      var topten = bizTier.GetTopStations(Convert.ToInt32(10));
                foreach (BusinessTier.CTAStation station in topten)
                {
                    this.lstStations.Items.Add(station.Name);
                }         

        toolStripStatusLabel1.Text = string.Format("Number of stations:  {0:#,##0}", topten.Count);
      }
      catch (Exception ex)
      {
        string msg = string.Format("Error in top 10 stations: '{0}'.", ex.Message);
        MessageBox.Show(msg);
      }
      
    }

		private void txtLocation_TextChanged(object sender, EventArgs e)
		{

		}

		private void txtDirection_TextChanged(object sender, EventArgs e)
		{

		}
	}//class
}//namespace
